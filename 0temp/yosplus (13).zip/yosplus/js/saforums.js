jQuery.cookie = function(l, j, b) {
    if ("undefined" != typeof j) {
        b = b || {};
        null === j && (j = "", b.expires = -1);
        var h = "";
        if (b.expires && ("number" == typeof b.expires || b.expires.toUTCString)) {
            "number" == typeof b.expires ? (h = new Date, h.setTime(h.getTime() + 86400000 * b.expires)) : h = b.expires, h = "; expires=" + h.toUTCString()
        }
        var d = b.path ? "; path=" + b.path : "",
            c = b.domain ? "; domain=" + b.domain : "",
            b = b.secure ? "; secure" : "";
        document.cookie = [l, "=", encodeURIComponent(j), h, d, c, b].join("")
    } else {
        j = null;
        if (document.cookie && "" != document.cookie) {
            b = document.cookie.split(";");
            for (h = 0; h < b.length; h++) {
                if (d = jQuery.trim(b[h]), d.substring(0, l.length + 1) == l + "=") {
                    j = decodeURIComponent(d.substring(l.length + 1));
                    break
                }
            }
        }
        return j
    }
};
window.SA || (SA = {});
SA.utils = new function(h, d, b) {
    var c = this;
    c.storageEnabled = h.localStorage ? !0 : !1;
    c.isMobile = /android|iphone|ipod|ipad|webos|blackberry/i.test(navigator.userAgent);
    c.store = function(f) {
        if (c.storageEnabled && null !== f) {
            var g = null;
            if (1 < arguments.length) {
                g = arguments[1], null === g ? localStorage.removeItem(f) : localStorage.setItem(f, JSON.stringify(g))
            } else {
                if (g = localStorage.getItem(f), null !== g) {
                    return JSON.parse(g)
                }
            }
        }
        return null
    };
    c.qs = function(e) {
        if (e) {
            var i = [],
                k;
            for (k in e) {
                i.push(encodeURIComponent(k) + "=" + encodeURIComponent(e[k]))
            }
            return i.join("&")
        }
        e = {};
        if (i = h.location.search) {
            for (var i = i.substr(1).split("&"), f = 0; f < i.length; f++) {
                k = i[f].indexOf("="), -1 == k ? e[i[f]] = "" : e[decodeURIComponent(i[f].substr(0, k))] = decodeURIComponent(i[f].substr(k + 1))
            }
        }
        return e
    };
    h.rf = function(a) {
        b("td.postbody iframe").css("height", Math.min(a, 800))
    }
}(window, document, jQuery);
new function(o, n, r) {
    var m = r.browser.webkit || r.browser.safari ? "body" : "html",
        l, d = 0,
        p = 0,
        h = function(b) {
            var e = Math.floor(160 * Math.random()) + 1;
            return "https://fi.somethingawful.com/sideimages/" + b + "88/" + e + ".jpg"
        },
        q = function() {
            l.offset();
            var a = r(m).scrollTop(),
                g = {
                    position: "absolute",
                    top: d
                },
                f = r("div#content"),
                c = f.offset().top,
                f = f.height(),
                c = c + f - p;
            a > c ? f > p && (g.top = c) : a >= d && (r.browser.msie && 7 > parseInt(r.browser.version, 10) ? g.top = a : (g.position = "fixed", g.top = 0));
            l.css(g)
        };
    r(n).ready(function() {
        var a = r("div.oma_pal"),
            b = r(new Image);
        b.attr({
            width: 88,
            height: 88,
            "class": "omapalpet"
        });
        b.css("display", "block");
        a.each(function(g, e) {
            var e = r(e),
                f = b.clone();
            f.addClass("left");
            f.attr("src", h("l"));
            e.prepend(f);
            f = b.clone();
            f.addClass("right");
            f.attr("src", h("r"));
            e.append(f)
        });
        l = r("div#unregskyscraper");
        l.length && (d = l.offset().top - 10, p = l.height() + 10, r(o).scroll(q));
        r("iframe.adframe").each(function(f, e) {
            r(e).attr("src", "/adframe.php?z=" + r(e).attr("data-zone"))
        })
    })
}(window, document, jQuery);

function newposts(a) {
    window.location.href = "/showthread.php?goto=newpost&threadid=" + a
}

function validate_pm(b, a) {
    return "" == b.message.value || "" == b.touser.value ? (alert("Please complete the recipient and message fields."), !1) : 0 != a && b.message.value.length > a / 2 ? (alert("Your message is too long.\n\nReduce your message to " + a / 2 + " characters.\nIt is currently " + b.message.value.length + " characters long."), !1) : !0
}

function posticon_sel(a) {
    document.vbform.iconid.item(a).checked = !0
}

function validate(d, c) {
    if (d.elements.namedItem("subject") && "" == d.subject.value) {
        return alert("Please complete the subject field, shithead."), !1
    }
    var b = d.elements.namedItem("message");
    return b && "" == d.message.value ? (alert("Please complete the message field, shithead."), !1) : 0 != c && b.length > c ? (alert("Your message is too long.\n\nReduce your message to " + c + " characters.\nIt is currently " + d.message.value.length + " characters long.\n  Are you trying to spam?\n  If so, then STOP!"), !1) : !0
}

function checklength(b, a) {
    a || (a = 0);
    message = 0 != a ? "\nThe maximum permitted length is " + a + " characters." : "";
    alert("Your message is " + b.message.value.length + " characters long." + message)
}

function rate_thread(a) {
    document.rateform.vote.value = a;
    document.rateform.submit()
}

function reloadCaptcha() {
    document.images.captcha.src = "captcha.php?" + Math.random()
}
$(document).ready(function() {
    var g = $("#thread table.post");
    $(g).each(function(l, q) {
        try {
            var p = $(q).find("td.userinfo").get(0),
                m = p.className.match(/\buserid\-(\d+)\b/)[1];
            $(p).data("userid", m);
            var r = q.id.match(/\bpost(\d+)\b/)[1];
            $(q).data({
                userid: m,
                postid: r
            });
            var n = $(q).find("tr td.postlinks ul.profilelinks"),
                i = 3 <= n.find("li").length ? 2 : 1;
            $(n).find("li:eq(" + i + ")", n).after('\n<li><a href="/banlist.php?userid=' + m + '">Rap Sheet</a></li>')
        } catch (o) {}
    });
    var d = RegExp(/^\(USER WAS (?:BANNED|PUT ON PROBATION) FOR THIS POST\)$/);
    $(g).each(function(f, j) {
        try {
            $(j).find("td.postbody > b:last").filter(function(e, i) {
                return !!$(i).text().match(d)
            }).wrapInner('<a href="/banlist.php?userid=' + $(j).data("userid") + '" />')
        } catch (h) {}
    });
    $("td.postbody .cancerous").closest("td").hover(function() {
        $(".cancerous", this).addClass("hover")
    }, function() {
        $(".cancerous", this).removeClass("hover")
    });
    var c = function() {
        return (!!document.createElement("video").canPlayType && (document.createElement("video").canPlayType('video/webm; codecs="vp8, vorbis"') === "probably"))
    };
    var b = function(e, f) {
        return '<source src="' + e.replace(f, ".mp4") + '" type="video/mp4"><source src="' + e.replace(f, ".webm") + '" type="video/webm">'
    };
    var a = $("td.postbody a");
    a = a.not("td.postbody:has(img[title=':nws:']) a").not(".postbody:has(img[title=':nms:']) a");
    a = a.not("td.bbc-spoiler a");
    a.each(function() {
        if (!/^http/.test($(this).text())) {
            return
        }
        var f = this.pathname.match(/(\.gifv|\.webm|\.mp4)$/i);
        if (f) {
            if (/(www\.|i\.)imgur.com$/i.test(this.hostname)) {
                $(this).replaceWith('<div class="gifv_video"><video autoplay loop muted="true" poster="' + $(this).attr("href").replace(f[1], "h.jpg") + '">' + b($(this).attr("href"), f[1]) + "</video></div>")
            } else {
                if (/gfycat.com$/i.test(this.hostname)) {
                    var k = this.pathname.match(/([A-Za-z]+)(?:\/*)?/i);
                    if (!k) {
                        return
                    }
                    var i = this;
                    $.ajax({
                        url: "https://gfycat.com/cajax/get/" + k[1],
                        dataType: "jsonp",
                        success: function(l) {
                            if (l.gfyItem) {
                                $(i).replaceWith('<div class="gfy_video"><video autoplay loop muted="true" poster="https://thumbs.gfycat.com/' + k[1] + '-poster.jpg"><source src="' + l.gfyItem.mp4Url + '" type="video/mp4"><source src="' + l.gfyItem.webmUrl + '" type="video/webm"></video></div>')
                            }
                        }
                    })
                } else {
                    if ((/\.gifv$/i).test(this.pathname)) {
                        return
                    } else {
                        if ((/\.webm$/i).test(this.pathname)) {
                            if (c()) {
                                $(this).replaceWith('<div class="sa_video"><video preload="metadata" controls>' + b($(this).attr("href"), f[1]) + "</video></div>")
                            }
                        } else {
                            $(this).replaceWith('<div class="sa_video"><video preload="metadata" controls>' + b($(this).attr("href"), f[1]) + "</video></div>")
                        }
                    }
                }
            }
        } else {
            var e = $(this).attr("href").match(/^(?:https|http):\/\/(?:mobile\.)?twitter.com\/[0-9a-zA-Z_]+\/(?:status|statuses)\/([0-9]+)/);
            if (e == null) {
                return
            }
            var j = e[1];
            var h = this;
            $.ajax({
                url: "https://api.twitter.com/1/statuses/oembed.json?id=" + j,
                dataType: "jsonp",
                success: function(l) {
                    h = $(h).wrap("<div class='tweet'>").parent();
                    $(h).html(l.html)
                }
            })
        }
    })
});

function add_whoposted_links() {
    $("#forum.threadlist tr.thread").each(function(h, d) {
        try {
            var b = d.id.match(/^thread(\d+)$/)[1];
            $("td.replies", d).wrapInner('<a href="/misc.php?action=whoposted&amp;threadid=' + b + '" target="_blank" title="List users that posted in this thread" />')
        } catch (c) {}
    })
}
new function(l, j, b) {
    var h = [],
        d = /thread(\d+)/i;
    b(new Image).attr("src", "https://fi.somethingawful.com/style/bookmarks/star-off.gif");
    b(new Image).attr("src", "https://fi.somethingawful.com/style/bookmarks/spin3.gif");
    for (var c = 0; 3 > c; c++) {
        h.push(b(new Image).attr("src", "https://fi.somethingawful.com/style/bookmarks/star" + c + ".gif"))
    }
    b(j).ready(function() {
        var o = b("tr.thread td.star");
        o.length && o.each(function(v, p) {
            var p = b(p),
                r = p.append("<div></div>"),
                u = p.parents("tr").eq(0),
                q = d.exec(u.attr("id"));
            if (q) {
                q = q[1];
                r.click(function() {
                    var f = b(this);
                    if (u.hasClass("spin")) {
                        return !1
                    }
                    u.addClass("spin");
                    u.removeClass("category0 category1 category2");
                    f.removeClass("bm0 bm1 bm2");
                    b.post("/bookmarkthreads.php", {
                        threadid: q,
                        action: "cat_toggle",
                        json: 1
                    }, function(g) {
                        0 <= g.category_id && !l.disable_thread_coloring && u.addClass("category" + g.category_id);
                        u.removeClass("spin");
                        f.addClass("bm" + g.category_id)
                    });
                    return !1
                });
                var s = u.find("div.lastseen"),
                    t = s.find("a.x");
                t.click(function() {
                    if (t.data("busy")) {
                        return !1
                    }
                    t.data("busy", !0);
                    t.html("<");
                    b.post("/showthread.php", {
                        threadid: q,
                        action: "resetseen",
                        json: 1
                    }, function(f) {
                        f.threadid && (u.removeClass("seen"), s.remove())
                    });
                    return !1
                })
            }
        });
        var e = !1,
            a = b("div#bookmark_link a"),
            i = b("img.thread_bookmark");
        if (a.length && i.length) {
            var n = parseInt(b("body").attr("data-thread"), 10),
                k = function() {
                    i.hasClass("unbookmark") ? a.html("Unbookmark this thread") : a.html("Bookmark this thread")
                },
                m = function() {
                    i.hasClass("bookmark") ? i.attr({
                        src: "https://fi.somethingawful.com/images/buttons/button-bookmark.png",
                        alt: "Bookmark",
                        title: "Bookmark thread"
                    }) : i.attr({
                        src: "https://fi.somethingawful.com/images/buttons/button-unbookmark.png",
                        alt: "Unbookmark",
                        title: "Unbookmark thread"
                    })
                },
                o = function() {
                    if (e) {
                        return !1
                    }
                    e = !0;
                    var f = {
                        action: i.hasClass("unbookmark") ? "remove" : "add",
                        threadid: n,
                        json: 1
                    };
                    b.post("/bookmarkthreads.php", f, function(g) {
                        i.removeClass("bookmark unbookmark");
                        g.bookmarked ? i.addClass("unbookmark") : i.addClass("bookmark");
                        m();
                        k();
                        e = !1
                    })
                };
            i.click(o);
            a.click(o);
            m();
            k()
        }
        if (b("body").hasClass("usercp") || b("body").hasClass("bookmark_threads")) {
            o = b("table#forum"), o.length && (o.find("thead > tr").append("<th></th>"), o.find("tbody > tr").append('<td class="button_remove"><div title="Remove bookmark"></div></td>'), o.delegate("td.button_remove div", "click", function() {
                var p = b(this),
                    f = p.parents("tr").eq(0),
                    g = d.exec(f.attr("id"));
                if (g) {
                    g = g[1];
                    if (p.data("pending")) {
                        return !1
                    }
                    p.data("pending", !0);
                    p.removeClass("warn");
                    p.addClass("spin");
                    b.post("/bookmarkthreads.php", {
                        threadid: g,
                        action: "remove",
                        json: 1
                    }, function() {
                        f.remove()
                    })
                }
                return !1
            }))
        }
    })
}(window, document, jQuery);
new function(d, c, b) {
    b(c).ready(function() {
        var h = b("div.threadrate"),
            g = "THANK GOD YOU VOTED!;Just the vote we were looking for.;You're a real gem.;Thanks toots.;*beep boop* vote accepted *bzzt*;We threw your vote into the pile.;Thank you, citizen!;That was the best vote I have ever seen.;That was a really good vote.;Vote accepted!  Thanks a lot!;Vot acepteed^ thinks aot;Thanks champ!".split(";");
        if (h.length) {
            var a = parseInt(b("body").attr("data-thread"), 10);
            0 >= a || isNaN(a) || h.delegate("ul.rating_buttons li", "click", function() {
                var e = b(this).index() + 1;
                b.post("/threadrate.php", {
                    threadid: a,
                    vote: e
                }, function() {
                    h.html(g[Math.floor(Math.random() * g.length)])
                })
            })
        }
    })
}(window, document, jQuery);
new function(l, j, b) {
    var h = "_sessl",
        h = h + "",
        d = function(e) {
            return parseInt(e, 10) + 0
        },
        c = function(i) {
            for (var i = i.substr(1).split("&"), n = 0, g, k = {}, o = i.length, m; n < o; n++) {
                g = i[n].indexOf("="), -1 != g && (m = i[n].substr(0, g), g = i[n].substr(g + 1), k[m] = g)
            }
            return k
        };
    b(j).ready(function() {
        if (b("div#notregistered").length) {
            b("table#forum th a").each(function(n, f) {
                b(f).replaceWith(f.childNodes)
            });
            b("ul.postbuttons img#button_bookmark").parent().remove();
            var m = l.location.search;
            if (m) {
                var i = c(m),
                    o = m = 0,
                    g = 0;
                if (i.hasOwnProperty("forumid")) {
                    m = d(i.forumid)
                } else {
                    var k = b('div.breadcrumbs a[href^="forumdisplay.php"]').last();
                    k.length && (k = k.attr("href"), k = c(k.substr(k.indexOf("?"))), k.hasOwnProperty("forumid") && (m = d(k.forumid)))
                }
                i.hasOwnProperty("threadid") && (o = d(i.threadid));
                i.hasOwnProperty("postid") && (g = d(i.postid));
                var i = !0,
                    k = d((new Date).getTime() / 1000),
                    a = b.cookie(h);
                if (a && (value = a.split("."), 4 == value.length)) {
                    var a = d(value[0]),
                        q = d(value[1]),
                        p = d(value[2]),
                        e = d(value[3]);
                    180 > k - e && (i = !1, a == m && q == o && p == g || (i = !0))
                }
                i && (m = [m, o, g, k].join("."), b.cookie(h, m, {
                    expires: 10,
                    domain: "forums.somethingawful.com"
                }), b("body").append('<img src="/s/' + m + '" alt="">'))
            }
        }
    })
}(window, document, jQuery);
window.SA || (SA = {});
SA.timg = new function(l, j, b) {
    var h = this,
        d = function(p, n) {
            var a = b(this).siblings("img"),
                k, o;
            if (a.attr("t_width")) {
                b(this).removeClass("expanded"), a.attr({
                    width: a.attr("t_width"),
                    height: a.attr("t_height")
                }), a.removeAttr("t_width"), a.removeAttr("t_height")
            } else {
                b(this).addClass("expanded");
                a.attr({
                    t_width: a.attr("width"),
                    t_height: a.attr("height")
                });
                var m = a.parents("blockquote");
                m.length || (m = a.parents(".postbody"));
                k = parseInt(a.attr("o_width"), 10);
                o = parseInt(a.attr("o_height"), 10);
                m = Math.min(900, m.width());
                if (n && k > m) {
                    var e = a.position(),
                        m = (m - 3 * e.left) / k;
                    a.attr("width", k * m);
                    a.attr("height", o * m)
                } else {
                    a.removeAttr("width"), a.removeAttr("height")
                }
                m = b.browser.webkit || b.browser.safari ? "body" : "html";
                o = b(m).scrollTop();
                k = a.offset().top;
                a = k + a.height();
                a - o > b(l).height() && (o = a - b(l).height());
                k < o && (o = k);
                o != b(m).scrollTop() && (b.browser.msie && 7 > parseInt(b.browser.version, 10) ? b(m).scrollTop(o) : b(m).animate({
                    scrollTop: o
                }, 150))
            }
            return !1
        },
        c = function() {
            var n = b(this);
            if (n.hasClass("loading")) {
                n.removeClass("loading");
                var k = n[0].naturalWidth || n.width(),
                    a = n[0].naturalHeight || n.height();
                if (200 > a && 500 >= k || 170 > k) {
                    n.removeClass("timg")
                } else {
                    n.addClass("complete");
                    n.attr({
                        o_width: k,
                        o_height: a
                    });
                    var k = k + "x" + a,
                        a = 1,
                        g = n[0].naturalWidth || n.width(),
                        m = n[0].naturalHeight || n.height();
                    170 < g && (a = 170 / g);
                    200 < m * a && (a = 200 / m);
                    n.attr({
                        width: g * a,
                        height: m * a
                    });
                    var a = b('<span class="timg_container"></span>'),
                        i = b('<div class="note"></div>');
                    i.text(k);
                    i.attr("title", "Click to toggle");
                    a.append(i);
                    n.before(a);
                    a.prepend(n);
                    i.click(d);
                    a.click(function(e) {
                        if (1 === e.which || b.browser.msie && 9 > parseInt(b.browser.version, 10) && 0 === e.which) {
                            return d.call(i, e, !0), !1
                        }
                    })
                }
                n.trigger("timg.loaded")
            }
        };
    h.scan = function(a) {
        b(a).find("img.timg").each(function(f, e) {
            e = b(e);
            e.hasClass("complete") || (e.addClass("loading"), e[0].complete || null !== e[0].naturalWidth && 0 < e[0].naturalWidth ? c.call(e) : e.load(c))
        })
    };
    b(j).ready(function() {
        h.scan("body")
    });
    b(l).load(function() {
        var a = b("img.timg.loading");
        a.length && a.each(function(e, f) {
            c.call(f)
        })
    })
}(window, document, jQuery);
(function(aC, aB, aG) {
    var aA = !1,
        ay = [],
        aw = {},
        aE = null,
        ax = null,
        aF = [],
        az = 0,
        aD = 0,
        at = 0,
        an = 0,
        ak = "",
        av = null,
        au = null,
        aj = !1,
        ag = aC.localStorage ? !0 : !1,
        T = aC.JSON && JSON.stringify && JSON.parse,
        ap = !1,
        ai = !1,
        aa = !1,
        af = !1,
        ae = 0,
        ad = function(b) {
            if (ag && null !== b) {
                var d = null,
                    b = "postreply_" + b;
                if (1 < arguments.length) {
                    d = arguments[1], null === d ? localStorage.removeItem(b) : localStorage.setItem(b, JSON.stringify(d))
                } else {
                    if (d = localStorage.getItem(b), null !== d) {
                        return JSON.parse(d)
                    }
                }
            }
            return null
        },
        Z = function(d) {
            var c = "\n";
            "\n" != aE[0].value.substr(aE[0].value.length - 1) && (c += "\n");
            ao(c + d, null, !1)
        },
        ac = function() {
            if (!aA && ay.length) {
                aA = !0;
                var a = aG(ay.shift());
                aw[a.attr("href")] ? (Z(aw[a.attr("href")]), ac()) : aG.get(a.attr("href") + "&json=1", {}, function(b) {
                    aw[a.attr("href")] = b.body;
                    Z(b.body);
                    a.children("img").attr("src", "https://fi.somethingawful.com/images/sa-quote-added.gif");
                    ac()
                }, "json")
            } else {
                aA = !1
            }
        },
        S = function() {
            aG(this).css("opacity", 0.6);
            ay.push(this);
            ac();
            return !1
        },
        Y = function() {
            if (ag && (null === aF || 1 < aF.length)) {
                var a = new Date,
                    b = null;
                if (ap) {
                    b = "forum-" + an
                } else {
                    if (ai) {
                        b = "reply-" + at
                    } else {
                        return
                    }
                }
                av.find("div.save-state").text("Saved: " + a.toLocaleDateString() + " " + a.toLocaleTimeString());
                ad(b, {
                    time: a.getTime(),
                    message: aG.trim(aE[0].value)
                })
            }
        },
        ah = function() {
            clearInterval(aD);
            if (null !== aF) {
                az != aF.length - 1 && aF.splice(az + 1, aF.length - az - 1);
                var b = aq();
                aF.push({
                    selection: b,
                    scroll: aE[0].scrollTop,
                    text: aE[0].value
                });
                az = aF.length - 1
            }
            Y()
        },
        X = function() {
            if (aF.length && 0 <= az && az < aF.length) {
                var b = aF[az].selection;
                aE[0].value = aF[az].text;
                am(b.start, b.end);
                aE[0].scrollTop = aF[az].scroll;
                ar();
                Y()
            }
        },
        W = function() {
            az = Math.min(aF.length - 1, az + 1);
            X()
        },
        al = function() {
            clearInterval(aD);
            aD = setTimeout(ah, 250)
        },
        aq = function() {
            var b = null;
            "new" == aj && (b = {
                start: aE[0].selectionStart,
                end: aE[0].selectionEnd
            });
            return b
        },
        am = function(b) {
            aE[0].setSelectionRange(b, 2 == arguments.length ? arguments[1] : b)
        },
        V = function(g) {
            for (var j = [
                    [0, 47],
                    [58, 64],
                    [91, 96],
                    [123, 126]
                ], f = 0, h = j.length, i = !1; f < h; f++) {
                if (g >= j[f][0] && g <= j[f][1]) {
                    i = !0;
                    break
                }
            }
            return i
        },
        U = function(f) {
            var c = aq(),
                g = aE[0].value,
                h = g.lastIndexOf("[" + f, c.start);
            return -1 != h ? (h = g.indexOf("[/" + f + "]", h), -1 == h ? !1 : h + 3 > c.end) : !1
        },
        ao = function(j, c, p) {
            null === c && (c = aq());
            var q = aE[0].scrollTop,
                l = aE[0].value,
                n = l.substring(0, c.start),
                m = l.substring(c.start, c.end),
                l = l.substr(c.end),
                k = c.start;
            p ? (p = "[" + j + "]" + m + "[/" + j + "]", aE[0].value = n + p, k = c.start == c.end ? c.start + j.length + 2 : c.start + p.length) : (aE[0].value = n + j, k = c.start + j.length);
            c.end = k;
            aE[0].scrollTop = aE[0].scrollHeight;
            aE[0].value += l;
            aE[0].scrollTop < q && (aE[0].scrollTop = q);
            am(k);
            ah();
            ar();
            return c
        },
        ab = function(f) {
            var f = f.split("&"),
                h = {},
                d, g;
            for (g in f) {
                d = f[g].indexOf("="), -1 != d ? h[f[g].substr(0, d)] = f[g].substr(d + 1) : h[f[g]] = !0
            }
            return h
        },
        R = function() {
            var d = aq(),
                c = null;
            return 5 <= d.start && (c = aE[0].value.substr(d.start - 5), /^(\[img\]|\[url\]|\[url="?)/.test(c)) || 6 <= d.start && (c = aE[0].value.substr(d.start - 6), /^\[timg\]/.test(c)) ? !0 : !1
        },
        o = function(h) {
            var c = null,
                m = "";
            if (h.originalEvent.metaKey || h.originalEvent.ctrlKey) {
                var n = null;
                switch (h.keyCode) {
                    case 66:
                        n = "b";
                        break;
                    case 73:
                        n = "i";
                        break;
                    case 76:
                        var n = aq(),
                            l = aE[0].value,
                            k = l.substring(0, n.start),
                            m = l.substring(n.start, n.end),
                            j = "[list]\n[*]" + m + "\n[/list]",
                            l = l.substr(n.end);
                        aE[0].value = k + j + l;
                        am(n.start + m.length + 10);
                        ah();
                        ar();
                        h.stopPropagation();
                        h.preventDefault();
                        return !1;
                    case 81:
                        n = "quote";
                        break;
                    case 83:
                        n = "s";
                        break;
                    case 85:
                        n = "u";
                        break;
                    case 86:
                        if (R()) {
                            break
                        }
                        c = aq();
                        ax.val("");
                        ax.focus();
                        setTimeout(function() {
                            var b = c,
                                v = ax[0].value;
                            if (/^https?:\/\//.test(v) && -1 == v.indexOf("\n") && -1 == v.indexOf("\r")) {
                                var u;
                                var r = /([^:]+):\/\/([^\/]+)(\/.*)?/.exec(decodeURI(v));
                                if (r) {
                                    var t = {
                                            scheme: r[1],
                                            domain: r[2],
                                            path: r[3] || "",
                                            filename: "",
                                            query: {},
                                            fragment: ""
                                        },
                                        r = t.path.lastIndexOf("#"); - 1 != r && (t.fragment = t.path.substr(r + 1), t.path = t.path.substr(0, r));
                                    r = t.path.lastIndexOf("?"); - 1 != r && (t.query = ab(t.path.substr(r + 1)), t.path = t.path.substr(0, r));
                                    r = t.path.lastIndexOf("/"); - 1 != r && (t.filename = t.path.substr(r + 1));
                                    u = t
                                } else {
                                    u = null
                                }
                                var t = r = "",
                                    s = false,
                                    q = u.filename.lastIndexOf("."); - 1 != q && (r = u.filename.substr(q + 1), t = u.filename.substr(0, q));
                                if (/^([^\.]+\.)?youtube(-nocookie)?\.com$/.test(u.domain) || /^([^\.]+\.)?youtu\.be$/.test(u.domain)) {
                                    var p = function(d) {
                                        var a = d.match(/(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s?)?/);
                                        return ((a[1] ? parseInt(a[1], 10) * 3600 : 0) + (a[2] ? parseInt(a[2], 10) * 60 : 0) + (a[3] ? parseInt(a[3], 10) : 0))
                                    };
                                    if (u.query.v) {
                                        v = '[video type="youtube"';
                                        if (u.query.hd) {
                                            v += ' res="hd"'
                                        }
                                        if (u.query.t) {
                                            v += ' start="' + p(u.query.t) + '"'
                                        } else {
                                            if (u.fragment) {
                                                s = ab(u.fragment);
                                                if (s.t) {
                                                    v += ' start="' + p(s.t) + '"'
                                                }
                                            }
                                        }
                                        v += "]" + u.query.v + "[/video]"
                                    } else {
                                        if (/^\/embed/.test(u.path)) {
                                            v = '[video type="youtube"', u.query.hd && (v += ' res="hd"'), u.query.start && (v += ' start="' + p(u.query.start) + '"'), v += "]" + u.path.substr(u.path.lastIndexOf("/") + 1) + "[/video]"
                                        } else {
                                            v = '[video type="youtube"';
                                            if (u.query.hd) {
                                                v += ' res="hd"'
                                            }
                                            if (u.query.t) {
                                                v += ' start="' + p(u.query.t) + '"'
                                            } else {
                                                if (u.fragment) {
                                                    s = ab(u.fragment);
                                                    if (s.t) {
                                                        v += ' start="' + p(s.t) + '"'
                                                    }
                                                }
                                            }
                                            v += "]" + u.path.substr(1) + "[/video]"
                                        }
                                    }
                                    s = true
                                }
                                if (!s) {
                                    switch (r) {
                                        case "jpg":
                                        case "gif":
                                        case "png":
                                            v = "[img]" + v + "[/img]"
                                    }
                                }
                            }
                            aE.focus();
                            ao(v, b, !1)
                        }, 50);
                        break;
                    case 88:
                        return al(), !0;
                    case 89:
                        return W(), h.preventDefault(), h.stopPropagation(), !1;
                    case 90:
                        return h.shiftKey ? W() : (az = Math.max(0, az - 1), X()), h.preventDefault(), h.stopPropagation(), !1
                }
                if (null !== n && (c = aq(), null !== c)) {
                    if (!h.shiftKey && c.start == c.end) {
                        m = aE[0].value;
                        k = c.start;
                        j = k - 1;
                        l = m.length;
                        for (k = {
                                start: k,
                                end: k
                            }; 0 <= j;) {
                            if (V(m.charCodeAt(j))) {
                                j++;
                                break
                            }
                            j--
                        }
                        for (k.start = j; j < l && !V(m.charCodeAt(j));) {
                            j++
                        }
                        k.end = j;
                        c = k
                    }
                    h.preventDefault();
                    h.stopPropagation();
                    ao(n, c, !0);
                    return !1
                }
            } else {
                n = null;
                switch (h.keyCode) {
                    case 13:
                        !h.shiftKey && U("list") && (n = "\n[*]");
                        break;
                    case 9:
                        U("code") && (n = "\t")
                }
                if (null !== n) {
                    return ao(n, null, !1), h.preventDefault(), h.stopPropagation(), !1
                }
                al()
            }
            return !0
        },
        ar = function() {
            var a = av.find("div.character-count"),
                c = aE[0].value.length;
            ae = c;
            if (0 < c && 50000 >= c && a.hasClass("over")) {
                a.removeClass("over"), aG('input.bginput[type="submit"]').attr("disabled", !1)
            } else {
                if (50000 < c || 0 === c) {
                    a.addClass("over"), aG('input.bginput[type="submit"]').attr("disabled", !0)
                }
            }
            af ? c = Math.round(100000 * Math.random()) - 50000 : 30000 < c && !a.is(":visible") && a.show();
            a.text(c + " / 50000")
        };
    aG(aB).ready(function() {
        ap = !!aG('form[action="newthread.php"]').length;
        ai = !!aG('form[action="newreply.php"]').length;
        aa = !!aG('form[action="editpost.php"]').length;
        af = !!aG("body.forum_26").length;
        if (ap || ai || aa) {
            aE = aG('textarea[name="message"]');
            av = aG('<div class="post-wrapper"></div>');
            aE.before(av);
            av.append('<div class="postinfo"><div class="save-state">New reply</div><div class="character-count">0 / 50000</div></div>');
            av.prepend(aE);
            aE.keyup(ar);
            aE.change(function() {
                al();
                ar()
            });
            setInterval(function() {
                ae != aE[0].value.length && (al(), ar())
            }, 1000);
            af && av.find("div.character-count").show();
            void 0 !== aE[0].selectionStart && void 0 !== aE[0].selectionEnd ? aj = "new" : aB.selection && (aj = "ie legacy");
            T && !ap && (aG(aB).delegate('td.postlinks > ul.postbuttons > li > a[href^="newreply.php"]', "click", S), au = aG("div#content > div.standard"), au.length || (au = aG('<div class="standard"><h2>Post Preview:</h2><div class="inner postbody"></div></div>'), au.css("width", "100%"), au.hide(), aG("div#content > div.breadcrumbs").after(au)));
            if (ag) {
                at = aG('input[name="threadid"]').val();
                an = aG('input[name="forumid"]').val();
                ak = aE[0].value;
                var c = null;
                ap ? c = ad("forum-" + an) : ai && (c = ad("reply-" + at));
                if (null !== c && c.message != ak) {
                    var a = av.find("div.save-state"),
                        b = new Date(c.time);
                    a.html("<strong>Draft from: " + b.toLocaleDateString() + " " + b.toLocaleTimeString() + "</strong>");
                    b = aG('<a href="#">Append</a>');
                    b.click(function() {
                        ao(c.message, null, !1);
                        return !1
                    });
                    a.append(b);
                    b = aG('<a href="#">Replace</a>');
                    b.click(function() {
                        aE[0].value = "";
                        ao(c.message, null, !1);
                        am(c.length);
                        return !1
                    });
                    a.append(b);
                    ap || (b = aG('<a href="#">Preview</a>'), b.click(function() {
                        var d = c.message,
                            f = {
                                action: aG('input[name="action"]').val(),
                                threadid: aG('input[name="threadid"]').val(),
                                formkey: aG('input[name="formkey"]').val(),
                                form_cookie: aG('input[name="form_cookie"]').val(),
                                preview: "Preview Reply",
                                message: d
                            };
                        aG('form[action="newreply.php"] input[type="checkbox"]:checked').each(function(e, g) {
                            g = aG(g);
                            f[g.attr("name")] = "yes"
                        });
                        aG.post("newreply.php?json=1", f, function(e) {
                            var g = au.find("div.postbody");
                            g.empty();
                            g.html(e.preview);
                            au.show();
                            SA.timg.scan(g);
                            ax.css({
                                top: aE.offset().top
                            });
                            e = aG.browser.webkit || aG.browser.safari ? "body" : "html";
                            g = au.offset();
                            g.top < aG(e).scrollTop() && aG(e).animate({
                                scrollTop: g.top
                            }, 150)
                        });
                        return !1
                    }), a.append(b))
                }
            } else {
                av.find("div.save-state").text("Drafts not enabled in your browser")
            }
            "new" == aj && (aC.adv_post_disabled ? (aF = null, aE.keyup(function() {
                ae != aE[0].value.length && (al(), ar())
            })) : (ax = aG("<textarea></textarea>"), ax.css({
                position: "absolute",
                left: -2000,
                top: aE.offset().top
            }), aG("body").append(ax), aE.keydown(o), am(aE[0].value.length), ah()));
            ar();
            aE.focus()
        }
    })
})(window, document, jQuery);
window.SA || (SA = {});
SA.thread = new function(o, n, b) {
    var m = /\?postid=(\d+)/,
        l = /#post(\d+)/,
        // if browser uses webkit and is not chrome (or is safari), use body as the base to apply the scroll animation
        // otherwise apply it on the root of the page using html tag
        d = (b.browser.webkit && !b.browser.chrome) || b.browser.safari ? "body" : "html",
        p = function(a) {
            var f = b("#" + a);
            if (f.length || "top" == a) {
                if (b.browser.msie && 9 > parseInt(b.browser.version, 10)) {
                    o.location.href = "#" + a
                } else {
                    var e = f.length ? f.offset().top : 0;
                    f.attr("id", "");
                    o.location.href = "#" + a;
                    f.attr("id", a);
                    b(d).animate({
                        scrollTop: e
                    }, 150)
                }
                return !1
            }
            return !0
        },
        h = function() {
            var a = b(this).attr("href"),
                c = null;
            if (/^https?:\/\//.test(a) && !/^https?:\/\/(.*\.)?forums\.somethingawful\./.test(a) || /^\/?attachment\.php/.test(a)) {
                return !0
            }
            m.test(a) ? c = m : l.test(a) && (c = l);
            return null !== c ? (a = "post" + c.exec(a)[1], p(a)) : !0
        };
    b(n).ready(function() {
        var a = b('<div class="jump_top left">UP</div>'),
            c = b('<div class="jump_top right">UP</div>');
        b(n).delegate("td.postbody a", "click", h);
        SA.utils.isMobile ? (b(".bbc-spoiler").bind("touchmove", function(e) {
            e.stopPropagation();
            e.preventDefault()
        }), b(".bbc-spoiler").bind("touchstart", function(e) {
            e.target == this && (b(this).toggleClass("stay"), e.stopPropagation(), e.preventDefault())
        })) : (b(".bbc-spoiler").click(function(e) {
            e.target == this && b(this).toggleClass("stay")
        }), b(".bbc-spoiler").hover(function() {
            b(this).addClass("reveal")
        }, function() {
            b(this).removeClass("reveal")
        }));
        b("body.showpost").length || (b.browser.msie && 7 > parseInt(b.browser.version, 10) ? (c.show(), b("body").append(c)) : (b("body").append(a), b("body").append(c), b(n).mousemove(function(j) {
            var k = a.is(":visible"),
                i = c.is(":visible"),
                e = j.pageY > b(d).scrollTop() + b(o).height() - 100;
            e && 100 > j.pageX ? (i && c.hide(), k || a.show()) : (e && j.pageX > b(o).width() - 100 ? i || c.show() : i && c.hide(), k && a.hide())
        })));
        b("div.jump_top").click(function() {
            return p("top")
        });
        b('form.forum_jump select[name="forumid"]').change(function() {
            var e = b(this),
                f = e.val(),
                e = e.siblings('input[name="daysprune"]').val();
            if (-1 == f) {
                return !1
            }
            o.location.href = "/forumdisplay.php?daysprune=" + e + "&forumid=" + f
        })
    });
    b(o).load(function() {
        if (b("body.showthread").length && o.adjust_page_position && o.location.hash) {
            var a = b(o.location.hash);
            a.length && (a = a.offset(), o.scrollTo(a.left, a.top))
        }
    })
}(window, document, jQuery);
new function(l, j, b) {
    var h = 0,
        d = null,
        c = function() {
            clearInterval(h);
            b.get("/flag.php?forumid=26", function(e) {
                d.attr("title", 'This flag proudly brought to you by "' + e.username + '" on ' + e.created);
                d.attr("src", "https://fi.somethingawful.com/flags" + e.path + "?by=" + encodeURIComponent(e.username));
                h = setTimeout(c, 60000)
            })
        };
    b(j).ready(function() {
        b(j).delegate("div.toggle_tags", "click", function() {
            b(this).parents("div#filter").eq(0).toggleClass("open")
        });
        b("div.pages select").change(function() {
            var g = b(this).attr("data-url");
            l.location.href = g + "&pagenumber=" + b(this).val()
        });
        if (b("body.forumdisplay, body.showthread").length) {
            var f = b("div.breadcrumbs > span:first-child");
            f.each(function(g, m) {
                var m = b(m),
                    n = [];
                m.find("a").each(function(o, p) {
                    n.push(b(p).clone())
                });
                m.html(" &rsaquo; ");
                m.append(n.pop());
                var k = b(n.pop());
                m.prepend(k);
                if (n.length) {
                    var i = b("<span></span>");
                    i.append(n);
                    i.append(k.clone());
                    k.prepend(i)
                }
                k.addClass("up")
            });
            f.prepend('<a class="index" href="/" title="Forums index">&laquo;</a>&nbsp;')
        }
        b(j).delegate("div.thread_tags a.if", "click", function(g) {
            if (g.shiftKey) {
                g = /posticon=(\d+)/.exec(b(this).attr("href"));
                if (!g) {
                    return !1
                }
                var g = g[1],
                    i = SA.utils.qs(),
                    k = null;
                if (i.posticon) {
                    if (-1 == ("," + i.posticon).indexOf("," + g)) {
                        k = i.posticon.split(",");
                        for (k.push(g); 10 < k.length;) {
                            k.shift()
                        }
                        i.posticon = k.join(",")
                    } else {
                        return !1
                    }
                } else {
                    i.posticon = g
                }
                l.location.href = "/forumdisplay.php?" + SA.utils.qs(i).replace(/%2c/ig, ",");
                return !1
            }
        });
        if (b("body.forum_26, body.forum_154").length) {
            d = b(new Image), b("div#flag_container").append(d), c()
        } else {
            if (!b.browser.msie && !b.browser.opera && !SA.utils.isMobile && b("body.forum_25").length) {
                f = b('<div id="gc_overlay"></div>'), b("body").append(f)
            } else {
                if (b("body.loginform").length) {
                    var e = b("input.secure_login"),
                        f = function() {
                            var g = b("form.login_form"),
                                i = "https://forums.somethingawful.com/account.php";
                            e.is(":checked") ? b.cookie("secure_login", null) : (i = "/account.php", b.cookie("secure_login", "no"));
                            g.attr("action", i)
                        };
                    e.click(f);
                    "no" == b.cookie("secure_login") && (e.attr("checked", null), f())
                }
            }
        }
        var a = RegExp("^" + b("#loggedinusername").text().replace(/([.*+?^${}()|\[\]\/\\])/g, "\\$1") + "\\s+posted:$");
        b(".bbc-block h4").filter(function() {
            return a.test(b(this).text())
        }).map(function() {
            return b(this).closest(".bbc-block")[0]
        }).addClass("userquoted")
    })
}(window, document, jQuery);

twemoji
twemoji.parse(document.body, {
    callback: function(icon, options, variant) {
        switch (icon) {
            case 'a9': // Â© copyright
            case 'ae': // Â® registered trademark
            case '2122': // â„¢ trademark
                return false;
        }
        return ''.concat(options.base, options.size, '/', icon, options.ext);
    }
});